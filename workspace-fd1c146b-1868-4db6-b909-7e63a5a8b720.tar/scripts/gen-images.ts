import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';

const OUT_DIR = path.join(process.cwd(), 'public/destinations');
const HERO_DIR = path.join(process.cwd(), 'public');
fs.mkdirSync(OUT_DIR, { recursive: true });
fs.mkdirSync(HERO_DIR, { recursive: true });

type Job = { prompt: string; size: string; file: string; dir: string };

const jobs: Job[] = [
  {
    prompt:
      'Cinematic wide photograph of a majestic South Indian Dravidian temple gopuram at golden sunrise, warm golden light, soft mist, dramatic clouds, spiritual atmosphere, intricate stone carvings, deep blacks, gold tones, ultra detailed, professional photography, no text',
    size: '1344x768',
    file: 'hero-temple.jpg',
    dir: HERO_DIR,
  },
  {
    prompt:
      'Tirumala Venkateswara temple golden gopuram tower at sunrise, ornate Dravidian architecture, warm golden light, blue sky, devotional atmosphere, detailed stone carvings of deities, professional travel photography, no text',
    size: '864x1152',
    file: 'tirupati.jpg',
    dir: OUT_DIR,
  },
  {
    prompt:
      'Sripuram Golden Temple Vellore at dusk, gleaming golden temple reflected in still water, star-shaped temple, warm golden glow, lush greenery, serene spiritual atmosphere, professional photography, no text',
    size: '864x1152',
    file: 'golden-temple.jpg',
    dir: OUT_DIR,
  },
  {
    prompt:
      'Arunachala hill at golden sunrise with Arunachaleswarar temple gopuram in foreground, sacred mountain, warm orange and gold light, mist in valleys, spiritual Tamil Nadu landscape, professional photography, no text',
    size: '864x1152',
    file: 'arunachalam.jpg',
    dir: OUT_DIR,
  },
  {
    prompt:
      'Srikalahasthi temple ancient gopuram tower, South Indian Dravidian architecture, weathered stone carvings of Shiva and Nandi, warm morning light, deep blue sky, devotional atmosphere, professional travel photography, no text',
    size: '864x1152',
    file: 'kalahasthi.jpg',
    dir: OUT_DIR,
  },
  {
    prompt:
      'Kanipakam Vinayaka temple serene courtyard with a stone Ganesha idol adorned with flowers and garlands, warm golden temple lamps, marigold flowers, devotional South Indian temple atmosphere, professional photography, no text',
    size: '864x1152',
    file: 'kanipakam.jpg',
    dir: OUT_DIR,
  },
  {
    prompt:
      'Ekambareswarar temple Kanchipuram massive stone gopuram, ancient South Indian Dravidian architecture, intricate carvings, a sacred mango tree in courtyard, warm golden evening light, professional travel photography, no text',
    size: '864x1152',
    file: 'kanchi.jpg',
    dir: OUT_DIR,
  },
  {
    prompt:
      'Thiruthani Murugan temple on a hilltop at golden sunset, steps leading up to a colorful gopuram, devotees, warm orange sky, sacred hill landscape, devotional atmosphere, professional photography, no text',
    size: '864x1152',
    file: 'thiruthani.jpg',
    dir: OUT_DIR,
  },
  {
    prompt:
      'Luxurious travel concept: a vintage leather suitcase with marigold flowers, brass diya oil lamp, incense, and a golden temple in soft-focus background, warm gold and dark moody lighting, premium travel brand aesthetic, no text',
    size: '1344x768',
    file: 'cta-journey.jpg',
    dir: HERO_DIR,
  },
];

async function main() {
  const zai = await ZAI.create();
  for (const job of jobs) {
    const outPath = path.join(job.dir, job.file);
    if (fs.existsSync(outPath)) {
      console.log(`skip (exists): ${outPath}`);
      continue;
    }
    try {
      console.log(`generating: ${job.file} (${job.size})`);
      const res = await zai.images.generations.create({
        prompt: job.prompt,
        size: job.size as any,
      });
      const b64 = res.data[0].base64;
      const buf = Buffer.from(b64, 'base64');
      fs.writeFileSync(outPath, buf);
      console.log(`  saved ${outPath} (${(buf.length / 1024).toFixed(0)} KB)`);
    } catch (e: any) {
      console.error(`  FAILED ${job.file}: ${e.message}`);
    }
  }
  console.log('done');
}

main();
