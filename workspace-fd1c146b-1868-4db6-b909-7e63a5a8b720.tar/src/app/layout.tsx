import type { Metadata } from "next";
import { Playfair_Display, Cormorant_Garamond, Inter } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const playfair = Playfair_Display({
  variable: "--font-playfair",
  subsets: ["latin"],
  weight: ["500", "600", "700", "800", "900"],
  display: "swap",
});

const cormorant = Cormorant_Garamond({
  variable: "--font-cormorant",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  style: ["normal", "italic"],
  display: "swap",
});

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Baadshah Tours & Travels · Sacred Journeys, Eternal Memories",
  description:
    "Baadshah Tours & Travels — trusted spiritual tour operator for Tirupati, Kalahasthi, Kanipakam, Golden Temple, Arunachalam, Kanchi & Thiruthani. Flight booking, hotels, tour packages & visa assistance. Chennai · Bangalore. Call 8328269906.",
  keywords: [
    "Baadshah Tours",
    "Tirupati tour package",
    "Kalahasthi temple tour",
    "Kanipakam temple",
    "Golden Temple Vellore",
    "Arunachalam temple",
    "Kanchi temples",
    "Thiruthani Murugan",
    "spiritual tours Chennai",
    "spiritual tours Bangalore",
    "flight booking",
    "hotel reservation",
    "visa assistance",
  ],
  authors: [{ name: "Baadshah Tours & Travels" }],
  openGraph: {
    title: "Baadshah Tours & Travels · Sacred Journeys",
    description:
      "Miles of Trust. Memories for Life. Spiritual tours to South India's most divine destinations.",
    siteName: "Baadshah Tours & Travels",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${playfair.variable} ${cormorant.variable} ${inter.variable} antialiased bg-ink text-cream font-sans`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
