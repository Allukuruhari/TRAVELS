import { NextResponse } from "next/server";
import { db } from "@/lib/db";

const PHONE_RE = /^[0-9+\-\s]{7,20}$/;

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => null);
    if (!body || typeof body !== "object") {
      return NextResponse.json(
        { error: "Invalid request body" },
        { status: 400 }
      );
    }

    const name = String(body.name ?? "").trim();
    const phone = String(body.phone ?? "").trim();
    const email = String(body.email ?? "").trim();
    const city = String(body.city ?? "").trim();
    const destination = String(body.destination ?? "").trim();
    const travellers = String(body.travellers ?? "").trim();
    const travelDate = String(body.travelDate ?? "").trim();
    const message = String(body.message ?? "").trim();

    if (name.length < 2) {
      return NextResponse.json({ error: "Please enter your name" }, { status: 400 });
    }
    if (!PHONE_RE.test(phone)) {
      return NextResponse.json(
        { error: "Please enter a valid phone number" },
        { status: 400 }
      );
    }
    if (!destination) {
      return NextResponse.json({ error: "Please select a destination" }, { status: 400 });
    }
    if (!travellers) {
      return NextResponse.json({ error: "Please select group size" }, { status: 400 });
    }
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json(
        { error: "Please enter a valid email" },
        { status: 400 }
      );
    }

    const inquiry = await db.inquiry.create({
      data: {
        name,
        phone,
        email: email || null,
        city: city || null,
        destination,
        travellers,
        travelDate: travelDate || null,
        message: message || null,
        status: "new",
      },
    });

    return NextResponse.json(
      { ok: true, id: inquiry.id, message: "Enquiry received" },
      { status: 201 }
    );
  } catch (err: any) {
    console.error("[inquiry] error:", err);
    return NextResponse.json(
      { error: "Something went wrong. Please try again or call us." },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    const count = await db.inquiry.count();
    return NextResponse.json({ count });
  } catch (err) {
    return NextResponse.json({ count: 0 });
  }
}
