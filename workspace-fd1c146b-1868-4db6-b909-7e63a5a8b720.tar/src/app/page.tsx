import { Navbar } from "@/components/site/navbar";
import { Hero } from "@/components/site/hero";
import { Destinations } from "@/components/site/destinations";
import { Services } from "@/components/site/services";
import { WhyUs } from "@/components/site/why-us";
import { Testimonials } from "@/components/site/testimonials";
import { InquiryForm } from "@/components/site/inquiry-form";
import { Footer } from "@/components/site/footer";
import { FloatingActions } from "@/components/site/floating-actions";

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col bg-ink">
      <Navbar />
      <main className="flex-1">
        <Hero />
        <Destinations />
        <Services />
        <WhyUs />
        <Testimonials />
        <InquiryForm />
      </main>
      <Footer />
      <FloatingActions />
    </div>
  );
}
