import {
  Plane,
  Hotel,
  Map,
  FileCheck,
  Headphones,
  Crown,
  ShieldCheck,
  Clock,
  HeartHandshake,
  type LucideIcon,
} from "lucide-react";

export type Destination = {
  slug: string;
  name: string;
  tagline: string;
  description: string;
  deity: string;
  location: string;
  image: string;
  highlight?: boolean;
};

export const destinations: Destination[] = [
  {
    slug: "tirupati",
    name: "Tirupati",
    tagline: "Abode of Lord Venkateswara",
    description:
      "Seek blessings at the world's most visited holy shrine. The seven peaks of Tirumala echo with centuries of devotion.",
    deity: "Lord Venkateswara",
    location: "Tirumala, Andhra Pradesh",
    image: "/destinations/tirupati.jpg",
    highlight: true,
  },
  {
    slug: "kalahasthi",
    name: "Srikalahasthi",
    tagline: "Rahu-Ketu Sthalam",
    description:
      "Experience divine grace at the Vayu Linga Kshetra — one of the Pancha Bhoota Sthalams of Lord Shiva.",
    deity: "Lord Shiva (Vayu Linga)",
    location: "Chittoor, Andhra Pradesh",
    image: "/destinations/kalahasthi.jpg",
  },
  {
    slug: "kanipakam",
    name: "Kanipakam",
    tagline: "The Self-Manifested Vinayaka",
    description:
      "The sacred temple of Lord Ganesha, where the idol grows in size and grants justice to devotees through sworn oath.",
    deity: "Lord Ganesha",
    location: "Chittoor, Andhra Pradesh",
    image: "/destinations/kanipakam.jpg",
  },
  {
    slug: "golden-temple",
    name: "Golden Temple",
    tagline: "Sripuram · Vellore",
    description:
      "Feel the serenity of the star-shaped Lakshmi Narayani temple sheathed in pure gold leaf. Embrace the divinity.",
    deity: "Goddess Lakshmi Narayani",
    location: "Vellore, Tamil Nadu",
    image: "/destinations/golden-temple.jpg",
    highlight: true,
  },
  {
    slug: "arunachalam",
    name: "Arunachalam",
    tagline: "The Fire Hill of Shiva",
    description:
      "Connect with the primal energy of Lord Shiva at Arunachala — the sacred hill of fire and the Girivalam path.",
    deity: "Lord Arunachaleswara",
    location: "Tiruvannamalai, Tamil Nadu",
    image: "/destinations/arunachalam.jpg",
  },
  {
    slug: "kanchi",
    name: "Kanchipuram",
    tagline: "City of a Thousand Temples",
    description:
      "Walk among ancient gopurams and the sacred mango tree of Ekambareswarar. A cradle of Dravidian temple art.",
    deity: "Lord Ekambareswara & Kamakshi",
    location: "Kanchipuram, Tamil Nadu",
    image: "/destinations/kanchi.jpg",
  },
  {
    slug: "thiruthani",
    name: "Thiruthani",
    tagline: "Six Abodes of Murugan",
    description:
      "Climb the 365 sacred steps to the hilltop shrine of Lord Murugan, where devotion meets panoramic serenity.",
    deity: "Lord Murugan",
    location: "Thiruttani, Tamil Nadu",
    image: "/destinations/thiruthani.jpg",
  },
];

export type Service = {
  icon: LucideIcon;
  title: string;
  description: string;
  features: string[];
};

export const services: Service[] = [
  {
    icon: Plane,
    title: "Flight Booking",
    description:
      "Best fares on domestic & international flights, with flexible itineraries for pilgrimage groups.",
    features: ["Domestic & international", "Group pilgrimage fares", "Instant e-ticketing"],
  },
  {
    icon: Hotel,
    title: "Hotel Reservation",
    description:
      "Handpicked hotels & dharmashalas near every temple, from budget comfort to luxury stays.",
    features: ["Temple-proximity stays", "Dharmashala options", "Family & group rooms"],
  },
  {
    icon: Map,
    title: "Tour Packages",
    description:
      "Curated spiritual itineraries across South India's holiest shrines, fully customizable.",
    features: ["Custom itineraries", "AC car & bus hire", "Local temple guides"],
  },
  {
    icon: FileCheck,
    title: "Visa Assistance",
    description:
      "End-to-end visa support for international devotees visiting Indian temples & pilgrim sites.",
    features: ["Tourist & e-visa", "Document guidance", "Application tracking"],
  },
  {
    icon: Headphones,
    title: "24/7 Support",
    description:
      "A dedicated travel desk that never sleeps — before, during, and after your sacred journey.",
    features: ["On-trip assistance", "Dedicated travel desk", "Emergency support"],
  },
];

export type Stat = { value: string; label: string };
export const stats: Stat[] = [
  { value: "12+", label: "Years of Service" },
  { value: "8,500+", label: "Devotees Travelled" },
  { value: "7", label: "Sacred Destinations" },
  { value: "24/7", label: "On-Trip Support" },
];

export type WhyCard = { icon: LucideIcon; title: string; text: string };
export const whyCards: WhyCard[] = [
  {
    icon: Crown,
    title: "Regal Experience",
    text: "Every journey is crafted with the dignity of a Baadshah — refined, reliable, and reverent.",
  },
  {
    icon: ShieldCheck,
    title: "Trusted & Safe",
    text: "Verified drivers, sanitized vehicles, and insured journeys. Your safety is our commandment.",
  },
  {
    icon: Clock,
    title: "On-Time, Always",
    text: "Darshan timings, seva slots, and flight departures — we honour every minute of your pilgrimage.",
  },
  {
    icon: HeartHandshake,
    title: "Devotee-First Care",
    text: "Senior-friendly assistance, dietary preferences, and personalized attention at every step.",
  },
];

export type Testimonial = {
  name: string;
  place: string;
  rating: number;
  text: string;
};

export const testimonials: Testimonial[] = [
  {
    name: "Srinivasa Rao",
    place: "Chennai",
    rating: 5,
    text: "Baadshah Tours arranged our Tirupati darshan seamlessly — right from VIP darshan tickets to a comfortable stay. Babji ji personally ensured our elderly parents were taken care of. Truly divine service!",
  },
  {
    name: "Lakshmi Narayanan",
    place: "Bangalore",
    rating: 5,
    text: "We did the Golden Temple + Arunachalam circuit. The car was spotless, the driver knew every shortcut and temple timing. Felt like a royal pilgrimage. Highly recommended for families.",
  },
  {
    name: "Priya Venkatesh",
    place: "Hyderabad",
    rating: 5,
    text: "Booked a group package for 14 of us to Kalahasthi and Kanipakam. Everything was handled — hotels, food, darshan. The Rahu-Ketu pooja arrangement was perfect. Thank you Baadshah team!",
  },
  {
    name: "Anand Krishnan",
    place: "Coimbatore",
    rating: 5,
    text: "Used their flight booking + hotel combo for a Thiruthani & Kanchi trip. Got the best fare and a temple-facing room. The 24/7 support line actually picked up at midnight. Impressive.",
  },
];

export const contact = {
  brand: "Baadshah Tours & Travels",
  proprietor: "Babji (Baadshah)",
  phone: "8328269906",
  phoneIntl: "+918328269906",
  whatsapp: "918328269906",
  cities: ["Chennai", "Bangalore"],
  email: "info@baadshahtours.com",
  website: "www.baadshahtours.com",
  tagline: "Miles of Trust. Memories for Life.",
};
