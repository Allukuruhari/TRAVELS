"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Send, Loader2, CheckCircle2, Phone, MessageCircle, Mail, MapPin } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { destinations, contact } from "@/lib/data";
import { SectionHeading } from "./section-heading";

const schema = z.object({
  name: z.string().min(2, "Please enter your name"),
  phone: z
    .string()
    .min(10, "Enter a valid 10-digit phone number")
    .regex(/^[0-9+\-\s]+$/, "Phone number contains invalid characters"),
  email: z.string().email("Enter a valid email").optional().or(z.literal("")),
  city: z.string().optional(),
  destination: z.string().min(1, "Select a destination"),
  travellers: z.string().min(1, "Select group size"),
  travelDate: z.string().optional(),
  message: z.string().optional(),
});

type FormValues = z.infer<typeof schema>;

export function InquiryForm() {
  const { toast } = useToast();
  const [submitted, setSubmitted] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    setValue,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      name: "",
      phone: "",
      email: "",
      city: "",
      destination: "",
      travellers: "",
      travelDate: "",
      message: "",
    },
  });

  const destinationValue = watch("destination");
  const travellersValue = watch("travellers");

  const onSubmit = async (data: FormValues) => {
    try {
      const res = await fetch("/api/inquiry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err?.error || "Something went wrong");
      }
      setSubmitted(true);
      toast({
        title: "Enquiry received! 🙏",
        description: "Our travel desk will call you within a few hours.",
      });
      reset();
    } catch (e: any) {
      toast({
        variant: "destructive",
        title: "Submission failed",
        description: e?.message || "Please try again or call us directly.",
      });
    }
  };

  return (
    <section id="inquiry" className="relative overflow-hidden bg-ink py-24 sm:py-32">
      <div className="pointer-events-none absolute left-0 top-1/4 h-[400px] w-[400px] rounded-full bg-gold/5 blur-[120px]" />
      <div className="absolute inset-0 bg-grain opacity-30" />

      <div className="relative mx-auto w-[min(1240px,94%)]">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-[1fr_1.1fr] lg:items-start">
          {/* Left: contact info */}
          <div>
            <SectionHeading
              align="left"
              eyebrow="Plan Your Yatra"
              title={
                <>
                  Let&apos;s Begin Your <span className="gold-gradient-text">Sacred Journey</span>
                </>
              }
              subtitle="Share a few details and our dedicated coordinator will craft a personalized itinerary — with the best fares, temple-proximity stays, and darshan arrangements."
            />

            <div className="mt-10 space-y-4">
              <a
                href={`tel:${contact.phoneIntl}`}
                className="group flex items-center gap-4 rounded-2xl border border-gold-soft bg-ink-card/60 p-4 transition hover:border-gold/50 hover:bg-gold/5"
              >
                <span className="grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br from-[#d6a94f] to-[#b8842c] text-[#1a1208]">
                  <Phone className="h-5 w-5" />
                </span>
                <span>
                  <span className="block text-xs tracking-wide text-cream-dim uppercase">
                    Call us · 24/7
                  </span>
                  <span className="font-serif text-xl font-bold text-cream">
                    {contact.phone}
                  </span>
                </span>
              </a>

              <a
                href={`https://wa.me/${contact.whatsapp}`}
                target="_blank"
                rel="noreferrer"
                className="group flex items-center gap-4 rounded-2xl border border-gold-soft bg-ink-card/60 p-4 transition hover:border-gold/50 hover:bg-gold/5"
              >
                <span className="grid h-12 w-12 place-items-center rounded-xl border border-gold/40 bg-ink text-gold">
                  <MessageCircle className="h-5 w-5" />
                </span>
                <span>
                  <span className="block text-xs tracking-wide text-cream-dim uppercase">
                    WhatsApp
                  </span>
                  <span className="font-serif text-lg font-bold text-cream">
                    Chat with us
                  </span>
                </span>
              </a>

              <a
                href={`mailto:${contact.email}`}
                className="group flex items-center gap-4 rounded-2xl border border-gold-soft bg-ink-card/60 p-4 transition hover:border-gold/50 hover:bg-gold/5"
              >
                <span className="grid h-12 w-12 place-items-center rounded-xl border border-gold/40 bg-ink text-gold">
                  <Mail className="h-5 w-5" />
                </span>
                <span>
                  <span className="block text-xs tracking-wide text-cream-dim uppercase">
                    Email
                  </span>
                  <span className="font-serif text-lg font-bold text-cream">
                    {contact.email}
                  </span>
                </span>
              </a>

              <div className="flex items-center gap-4 rounded-2xl border border-gold-soft bg-ink-card/60 p-4">
                <span className="grid h-12 w-12 place-items-center rounded-xl border border-gold/40 bg-ink text-gold">
                  <MapPin className="h-5 w-5" />
                </span>
                <span>
                  <span className="block text-xs tracking-wide text-cream-dim uppercase">
                    Serving from
                  </span>
                  <span className="font-serif text-lg font-bold text-cream">
                    {contact.cities.join(" · ")}
                  </span>
                </span>
              </div>
            </div>
          </div>

          {/* Right: form */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.6 }}
            className="relative overflow-hidden rounded-3xl border border-gold-soft bg-ink-card/70 p-6 backdrop-blur-md sm:p-8"
          >
            <div className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-gold/10 blur-3xl" />

            {submitted ? (
              <div className="flex min-h-[420px] flex-col items-center justify-center text-center">
                <div className="grid h-20 w-20 place-items-center rounded-full bg-gold/15">
                  <CheckCircle2 className="h-10 w-10 text-gold" />
                </div>
                <h3 className="mt-6 font-serif text-3xl font-bold text-cream">
                  Enquiry Received 🙏
                </h3>
                <p className="mt-3 max-w-sm text-cream/70">
                  Thank you for choosing Baadshah Tours &amp; Travels. Our travel
                  desk will reach out to you shortly.
                </p>
                <p className="mt-4 font-display text-sm text-gold-soft">
                  For urgent bookings, call{" "}
                  <a href={`tel:${contact.phoneIntl}`} className="font-bold underline">
                    {contact.phone}
                  </a>
                </p>
                <Button
                  variant="outline"
                  className="mt-6 border-gold-soft bg-transparent text-gold hover:bg-gold/10"
                  onClick={() => setSubmitted(false)}
                >
                  Submit another enquiry
                </Button>
              </div>
            ) : (
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                  <Field label="Full Name" error={errors.name?.message} required>
                    <Input
                      {...register("name")}
                      placeholder="Your name"
                      className="bg-ink/60 border-gold-soft text-cream placeholder:text-cream-dim/60 focus:border-gold"
                    />
                  </Field>
                  <Field label="Phone" error={errors.phone?.message} required>
                    <Input
                      {...register("phone")}
                      type="tel"
                      placeholder="10-digit mobile"
                      className="bg-ink/60 border-gold-soft text-cream placeholder:text-cream-dim/60 focus:border-gold"
                    />
                  </Field>
                </div>

                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                  <Field label="Email (optional)" error={errors.email?.message}>
                    <Input
                      {...register("email")}
                      type="email"
                      placeholder="you@email.com"
                      className="bg-ink/60 border-gold-soft text-cream placeholder:text-cream-dim/60 focus:border-gold"
                    />
                  </Field>
                  <Field label="Your City" error={errors.city?.message}>
                    <Input
                      {...register("city")}
                      placeholder="e.g. Chennai"
                      className="bg-ink/60 border-gold-soft text-cream placeholder:text-cream-dim/60 focus:border-gold"
                    />
                  </Field>
                </div>

                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                  <Field label="Destination" error={errors.destination?.message} required>
                    <Select
                      value={destinationValue}
                      onValueChange={(v) => setValue("destination", v, { shouldValidate: true })}
                    >
                      <SelectTrigger className="bg-ink/60 border-gold-soft text-cream focus:border-gold">
                        <SelectValue placeholder="Choose shrine" />
                      </SelectTrigger>
                      <SelectContent className="bg-ink-card border-gold-soft text-cream">
                        {destinations.map((d) => (
                          <SelectItem
                            key={d.slug}
                            value={d.name}
                            className="focus:bg-gold/15 focus:text-gold"
                          >
                            {d.name}
                          </SelectItem>
                        ))}
                        <SelectItem value="Custom Package" className="focus:bg-gold/15 focus:text-gold">
                          Custom Package
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </Field>
                  <Field label="Travellers" error={errors.travellers?.message} required>
                    <Select
                      value={travellersValue}
                      onValueChange={(v) => setValue("travellers", v, { shouldValidate: true })}
                    >
                      <SelectTrigger className="bg-ink/60 border-gold-soft text-cream focus:border-gold">
                        <SelectValue placeholder="Group size" />
                      </SelectTrigger>
                      <SelectContent className="bg-ink-card border-gold-soft text-cream">
                        {["1 - 2", "3 - 5", "6 - 10", "11 - 20", "20+"].map((n) => (
                          <SelectItem
                            key={n}
                            value={n}
                            className="focus:bg-gold/15 focus:text-gold"
                          >
                            {n}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </Field>
                </div>

                <Field label="Preferred Travel Date (optional)">
                  <Input
                    {...register("travelDate")}
                    type="date"
                    className="bg-ink/60 border-gold-soft text-cream placeholder:text-cream-dim/60 focus:border-gold [color-scheme:dark]"
                  />
                </Field>

                <Field label="Message (optional)">
                  <Textarea
                    {...register("message")}
                    placeholder="Tell us about your pilgrimage plans, special needs, darshan preferences..."
                    rows={3}
                    className="resize-none bg-ink/60 border-gold-soft text-cream placeholder:text-cream-dim/60 focus:border-gold"
                  />
                </Field>

                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-gradient-to-r from-[#e8c078] to-[#d6a94f] text-[#1a1208] text-base font-bold hover:from-[#f0d088] hover:to-[#e8c078] disabled:opacity-60"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4" />
                      Request Free Quote
                    </>
                  )}
                </Button>
                <p className="text-center text-xs text-cream-dim">
                  We respect your privacy. Your details are only used to plan
                  your journey.
                </p>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function Field({
  label,
  children,
  error,
  required,
}: {
  label: string;
  children: React.ReactNode;
  error?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-sm font-medium text-cream/80">
        {label} {required && <span className="text-gold">*</span>}
      </label>
      {children}
      {error && <p className="mt-1 text-xs text-red-400">{error}</p>}
    </div>
  );
}
