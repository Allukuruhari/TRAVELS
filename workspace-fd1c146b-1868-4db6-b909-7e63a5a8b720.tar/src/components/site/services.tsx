"use client";

import { motion } from "framer-motion";
import { Check } from "lucide-react";
import { services } from "@/lib/data";
import { SectionHeading } from "./section-heading";

export function Services() {
  return (
    <section id="services" className="relative overflow-hidden bg-ink-soft py-24 sm:py-32">
      <div className="absolute inset-0 bg-grain opacity-30" />
      <div className="pointer-events-none absolute right-0 top-1/3 h-[400px] w-[400px] rounded-full bg-gold/5 blur-[120px]" />

      <div className="relative mx-auto w-[min(1240px,94%)]">
        <SectionHeading
          eyebrow="Our Services"
          title={
            <>
              Everything for a <span className="gold-gradient-text">Seamless Yatra</span>
            </>
          }
          subtitle="From the first booking to the final blessing — a complete travel desk devoted to your pilgrimage."
        />

        <div className="mt-16 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s, i) => {
            const Icon = s.icon;
            return (
              <motion.div
                key={s.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.5, delay: (i % 3) * 0.08 }}
                className="group relative overflow-hidden rounded-3xl border border-gold-soft bg-ink-card/70 p-7 transition duration-500 hover:-translate-y-1 hover:border-gold/50"
              >
                <div className="pointer-events-none absolute -right-8 -top-8 h-32 w-32 rounded-full bg-gold/10 opacity-0 blur-2xl transition group-hover:opacity-100" />
                <div className="relative flex items-start gap-4">
                  <div className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl border border-gold/40 bg-gradient-to-br from-[#2a1f0e] to-ink text-gold transition group-hover:scale-110 group-hover:border-gold">
                    <Icon className="h-6 w-6" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-serif text-xl font-bold text-cream">
                      {s.title}
                    </h3>
                    <p className="mt-1.5 text-sm leading-relaxed text-cream/70">
                      {s.description}
                    </p>
                  </div>
                </div>
                <ul className="mt-5 space-y-2 border-t border-gold-soft pt-4">
                  {s.features.map((f) => (
                    <li
                      key={f}
                      className="flex items-center gap-2 text-sm text-cream/80"
                    >
                      <span className="grid h-4 w-4 place-items-center rounded-full bg-gold/15">
                        <Check className="h-3 w-3 text-gold" />
                      </span>
                      {f}
                    </li>
                  ))}
                </ul>
              </motion.div>
            );
          })}

          {/* 6th cell: assurance card */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.5, delay: 0.16 }}
            className="relative flex flex-col justify-center overflow-hidden rounded-3xl border border-gold bg-gradient-to-br from-[#d6a94f] via-[#c99b3c] to-[#b8842c] p-7 text-[#1a1208]"
          >
            <div className="pointer-events-none absolute inset-0 bg-grain opacity-20" />
            <div className="relative">
              <p className="font-display text-sm tracking-[0.3em] uppercase opacity-80">
                The Baadshah Promise
              </p>
              <h3 className="mt-2 font-serif text-3xl font-black leading-tight">
                Comfort · Safety · Memories
              </h3>
              <p className="mt-3 text-sm font-medium opacity-90">
                One dedicated coordinator handles your entire journey —
                flights, hotels, darshan, transport and 24/7 on-trip support.
              </p>
              <a
                href="#inquiry"
                className="mt-5 inline-flex items-center gap-2 rounded-full bg-ink px-5 py-2.5 text-sm font-bold text-gold transition hover:bg-ink-card"
              >
                Get a Free Quote
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
