"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Menu, X, Phone, Crown } from "lucide-react";
import { cn } from "@/lib/utils";
import { contact } from "@/lib/data";

const navLinks = [
  { label: "Home", href: "#home" },
  { label: "Destinations", href: "#destinations" },
  { label: "Services", href: "#services" },
  { label: "Why Us", href: "#why" },
  { label: "Reviews", href: "#testimonials" },
  { label: "Contact", href: "#inquiry" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        scrolled
          ? "bg-ink/90 backdrop-blur-xl border-b border-gold-soft py-3"
          : "bg-transparent py-5"
      )}
    >
      <div className="mx-auto flex w-[min(1240px,94%)] items-center justify-between">
        <Link href="#home" className="group flex items-center gap-3">
          <span className="relative grid h-11 w-11 place-items-center rounded-full border border-gold/60 bg-gradient-to-br from-[#3a2a10] to-[#0a0a0a]">
            <Crown className="h-5 w-5 text-gold" />
            <span className="absolute inset-0 rounded-full ring-1 ring-gold/20 transition group-hover:ring-gold/50" />
          </span>
          <span className="leading-none">
            <span className="block font-serif text-2xl font-extrabold tracking-tight text-cream">
              BAAD<span className="gold-gradient-text">S</span>HAH
            </span>
            <span className="block font-display text-[11px] tracking-[0.35em] text-gold-soft">
              TOURS & TRAVELS
            </span>
          </span>
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          {navLinks.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className="group relative rounded-full px-4 py-2 text-sm font-medium text-cream/80 transition hover:text-gold"
            >
              {l.label}
              <span className="absolute inset-x-4 -bottom-0.5 h-px scale-x-0 bg-gold transition-transform duration-300 group-hover:scale-x-100" />
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <a
            href={`tel:${contact.phoneIntl}`}
            className="hidden items-center gap-2 rounded-full bg-gold px-5 py-2.5 text-sm font-bold text-[#1a1208] transition hover:bg-gold-bright hover:shadow-[0_0_30px_-5px_rgba(214,169,79,0.6)] sm:flex"
          >
            <Phone className="h-4 w-4" />
            {contact.phone}
          </a>
          <button
            aria-label="Toggle menu"
            onClick={() => setOpen((v) => !v)}
            className="grid h-11 w-11 place-items-center rounded-full border border-gold-soft text-gold transition hover:bg-gold/10 lg:hidden"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <div
        className={cn(
          "lg:hidden overflow-hidden transition-[max-height,opacity] duration-500 ease-in-out",
          open ? "max-h-[420px] opacity-100" : "max-h-0 opacity-0"
        )}
      >
        <nav className="mx-auto mt-3 w-[min(1240px,94%)] rounded-2xl border border-gold-soft bg-ink-card/95 p-4 backdrop-blur-xl">
          {navLinks.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="block rounded-xl px-4 py-3 text-base font-medium text-cream/90 transition hover:bg-gold/10 hover:text-gold"
            >
              {l.label}
            </Link>
          ))}
          <a
            href={`tel:${contact.phoneIntl}`}
            className="mt-2 flex items-center justify-center gap-2 rounded-xl bg-gold px-4 py-3 text-base font-bold text-[#1a1208]"
          >
            <Phone className="h-4 w-4" />
            Call {contact.phone}
          </a>
        </nav>
      </div>
    </header>
  );
}
