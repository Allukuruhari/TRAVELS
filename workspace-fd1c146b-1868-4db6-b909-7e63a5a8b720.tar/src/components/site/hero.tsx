"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Phone, MessageCircle, ChevronDown, Star, Sparkles } from "lucide-react";
import { motion } from "framer-motion";
import { contact } from "@/lib/data";

export function Hero() {
  const [loaded, setLoaded] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setLoaded(true), 50);
    return () => clearTimeout(t);
  }, []);

  return (
    <section
      id="home"
      className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-ink"
    >
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src="/hero-temple.jpg"
          alt="South Indian temple gopuram at golden sunrise"
          className={`h-full w-full object-cover transition-opacity duration-[2000ms] ${
            loaded ? "opacity-50" : "opacity-0"
          }`}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-ink/70 via-ink/60 to-ink" />
        <div className="absolute inset-0 bg-gradient-to-r from-ink/80 via-transparent to-ink/40" />
        <div className="absolute inset-0 bg-grain opacity-60" />
      </div>

      {/* Decorative spinning mandala */}
      <div
        className="pointer-events-none absolute -top-1/3 left-1/2 h-[120vh] w-[120vh] -translate-x-1/2 rounded-full opacity-30"
        style={{
          background:
            "repeating-radial-gradient(circle, rgba(214,169,79,0.12) 0 1px, transparent 1px 46px)",
          animation: "spin 60s linear infinite",
        }}
      />
      <div
        className="pointer-events-none absolute right-[8%] top-[18%] h-72 w-72 rounded-full opacity-60 blur-[80px]"
        style={{ background: "radial-gradient(circle, #d6a94f55, transparent 70%)" }}
      />

      {/* Content */}
      <div className="relative z-10 mx-auto w-[min(1240px,94%)] px-2 pt-28 pb-16 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="mb-6 inline-flex items-center gap-3 rounded-full border border-gold-soft bg-ink-card/60 px-5 py-2 backdrop-blur-md"
        >
          <Sparkles className="h-4 w-4 text-gold" />
          <span className="font-display text-sm tracking-[0.4em] text-gold-soft uppercase">
            Spiritual Journeys · Since 2012
          </span>
          <Sparkles className="h-4 w-4 text-gold" />
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.9, delay: 0.2, ease: "easeOut" }}
          className="font-serif text-[clamp(56px,12vw,150px)] font-black leading-[0.9] tracking-tight text-cream text-glow-gold"
        >
          BAAD<span className="gold-shimmer">S</span>HAH
        </motion.h1>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.45 }}
          className="mt-4 flex flex-col items-center gap-2"
        >
          <p className="font-display text-2xl italic tracking-wide text-gold-soft sm:text-3xl">
            Tours &amp; Travels
          </p>
          <div className="gold-divider w-40" />
          <p className="font-display text-lg tracking-[0.15em] text-cream/80 sm:text-xl">
            {contact.tagline}
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.65 }}
          className="mx-auto mt-8 max-w-2xl text-balance font-sans text-base text-cream/70 sm:text-lg"
        >
          Guiding devotees to South India&apos;s most sacred shrines —
          Tirupati, Kalahasthi, Kanipakam, the Golden Temple, Arunachalam,
          Kanchi &amp; Thiruthani. Comfort, devotion, and unforgettable memories.
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.8 }}
          className="mt-9 flex flex-wrap items-center justify-center gap-4"
        >
          <a
            href={`tel:${contact.phoneIntl}`}
            className="group inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-[#e8c078] to-[#d6a94f] px-7 py-3.5 text-sm font-bold text-[#1a1208] shadow-[0_10px_40px_-10px_rgba(214,169,79,0.6)] transition hover:shadow-[0_14px_50px_-8px_rgba(214,169,79,0.8)]"
          >
            <Phone className="h-4 w-4 transition group-hover:rotate-12" />
            Call {contact.phone}
          </a>
          <a
            href={`https://wa.me/${contact.whatsapp}`}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 rounded-full border border-gold-soft bg-ink-card/40 px-7 py-3.5 text-sm font-bold text-cream backdrop-blur-md transition hover:border-gold hover:bg-gold/10 hover:text-gold"
          >
            <MessageCircle className="h-4 w-4" />
            WhatsApp Us
          </a>
          <Link
            href="#destinations"
            className="inline-flex items-center gap-2 rounded-full px-5 py-3.5 text-sm font-semibold text-cream/80 transition hover:text-gold"
          >
            Explore Destinations
            <ChevronDown className="h-4 w-4 animate-bounce" />
          </Link>
        </motion.div>

        {/* Rating row */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, delay: 1 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-cream/70"
        >
          <span className="inline-flex items-center gap-1.5">
            <span className="flex">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-4 w-4 fill-gold text-gold" />
              ))}
            </span>
            4.9 / 5 from 1,200+ devotees
          </span>
          <span className="hidden h-4 w-px bg-gold-soft sm:block" />
          <span className="font-display tracking-wide text-gold-soft">
            Chennai · Bangalore
          </span>
        </motion.div>
      </div>

      {/* Bottom marquee */}
      <div className="relative z-10 w-full border-y border-gold-soft bg-ink-card/40 py-3 backdrop-blur-sm">
        <div className="flex overflow-hidden whitespace-nowrap">
          <div className="animate-marquee flex shrink-0 items-center gap-10 pr-10 font-display text-sm tracking-[0.25em] text-gold-soft uppercase">
            {[
              "✦ Tirupati",
              "✦ Srikalahasthi",
              "✦ Kanipakam",
              "✦ Golden Temple",
              "✦ Arunachalam",
              "✦ Kanchipuram",
              "✦ Thiruthani",
              "✦ Tirupati",
              "✦ Srikalahasthi",
              "✦ Kanipakam",
              "✦ Golden Temple",
              "✦ Arunachalam",
              "✦ Kanchipuram",
              "✦ Thiruthani",
            ].map((t, i) => (
              <span key={i} className="flex items-center">
                {t}
              </span>
            ))}
          </div>
        </div>
      </div>

      <style>{`@keyframes spin{to{transform:translate(-50%,0) rotate(360deg)}}`}</style>
    </section>
  );
}
