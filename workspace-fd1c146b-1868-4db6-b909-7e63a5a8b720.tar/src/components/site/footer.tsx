"use client";

import Link from "next/link";
import { Crown, Phone, Mail, MapPin, MessageCircle, Facebook, Instagram, Youtube, Send } from "lucide-react";
import { contact, destinations, services } from "@/lib/data";

export function Footer() {
  return (
    <footer className="relative mt-auto border-t border-gold-soft bg-ink-soft">
      <div className="absolute inset-0 bg-grain opacity-30" />
      <div className="relative mx-auto w-[min(1240px,94%)] py-16">
        <div className="grid grid-cols-1 gap-12 md:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3">
              <span className="grid h-12 w-12 place-items-center rounded-full border border-gold/60 bg-gradient-to-br from-[#3a2a10] to-ink">
                <Crown className="h-5 w-5 text-gold" />
              </span>
              <span className="leading-none">
                <span className="block font-serif text-2xl font-extrabold text-cream">
                  BAAD<span className="gold-gradient-text">S</span>HAH
                </span>
                <span className="block font-display text-[11px] tracking-[0.35em] text-gold-soft">
                  TOURS & TRAVELS
                </span>
              </span>
            </div>
            <p className="mt-5 font-display text-lg italic text-gold-soft">
              {contact.tagline}
            </p>
            <p className="mt-3 text-sm leading-relaxed text-cream/70">
              Your Journey. Our Priority. <br />
              <span className="text-cream/90">Comfort · Safety · Memories.</span>
            </p>
            <div className="mt-5 flex gap-3">
              {[
                { icon: Facebook, href: "#", label: "Facebook" },
                { icon: Instagram, href: "#", label: "Instagram" },
                { icon: Youtube, href: "#", label: "YouTube" },
                { icon: Send, href: `https://wa.me/${contact.whatsapp}`, label: "WhatsApp" },
              ].map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  aria-label={s.label}
                  className="grid h-10 w-10 place-items-center rounded-full border border-gold-soft text-gold transition hover:bg-gold hover:text-[#1a1208]"
                >
                  <s.icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Destinations */}
          <div>
            <h4 className="font-serif text-lg font-bold text-cream">Destinations</h4>
            <div className="mt-2 h-px w-10 bg-gold/50" />
            <ul className="mt-5 space-y-2.5">
              {destinations.map((d) => (
                <li key={d.slug}>
                  <a
                    href="#destinations"
                    className="text-sm text-cream/70 transition hover:text-gold"
                  >
                    {d.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-serif text-lg font-bold text-cream">Services</h4>
            <div className="mt-2 h-px w-10 bg-gold/50" />
            <ul className="mt-5 space-y-2.5">
              {services.map((s) => (
                <li key={s.title}>
                  <a
                    href="#services"
                    className="text-sm text-cream/70 transition hover:text-gold"
                  >
                    {s.title}
                  </a>
                </li>
              ))}
              <li>
                <a href="#inquiry" className="text-sm text-cream/70 transition hover:text-gold">
                  Custom Packages
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-serif text-lg font-bold text-cream">Get in Touch</h4>
            <div className="mt-2 h-px w-10 bg-gold/50" />
            <ul className="mt-5 space-y-4">
              <li>
                <a
                  href={`tel:${contact.phoneIntl}`}
                  className="group flex items-start gap-3"
                >
                  <Phone className="mt-0.5 h-4 w-4 shrink-0 text-gold" />
                  <span>
                    <span className="block text-xs text-cream-dim uppercase">
                      Proprietor · {contact.proprietor}
                    </span>
                    <span className="font-serif text-xl font-bold gold-gradient-text">
                      {contact.phone}
                    </span>
                  </span>
                </a>
              </li>
              <li>
                <a
                  href={`https://wa.me/${contact.whatsapp}`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-3 text-sm text-cream/70 transition hover:text-gold"
                >
                  <MessageCircle className="h-4 w-4 shrink-0 text-gold" />
                  WhatsApp Chat
                </a>
              </li>
              <li>
                <a
                  href={`mailto:${contact.email}`}
                  className="flex items-center gap-3 text-sm text-cream/70 transition hover:text-gold"
                >
                  <Mail className="h-4 w-4 shrink-0 text-gold" />
                  {contact.email}
                </a>
              </li>
              <li className="flex items-center gap-3 text-sm text-cream/70">
                <MapPin className="h-4 w-4 shrink-0 text-gold" />
                {contact.cities.join(" · ")}
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 gold-divider" />

        <div className="mt-6 flex flex-col items-center justify-between gap-3 sm:flex-row">
          <p className="text-center text-xs text-cream-dim sm:text-left">
            © {new Date().getFullYear()} Baadshah Tours &amp; Travels. All rights reserved.
          </p>
          <p className="text-center text-xs text-cream-dim sm:text-right">
            <Link href="#home" className="transition hover:text-gold">
              {contact.website}
            </Link>
            {" · "}
            Crafted with devotion 🕉
          </p>
        </div>
      </div>
    </footer>
  );
}
