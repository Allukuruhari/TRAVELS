"use client";

import { motion } from "framer-motion";
import { MapPin, ArrowUpRight, Sparkles } from "lucide-react";
import { destinations } from "@/lib/data";
import { SectionHeading } from "./section-heading";

export function Destinations() {
  return (
    <section id="destinations" className="relative overflow-hidden bg-ink py-24 sm:py-32">
      {/* ambient glow */}
      <div className="pointer-events-none absolute left-1/2 top-0 h-[400px] w-[600px] -translate-x-1/2 rounded-full bg-gold/5 blur-[120px]" />
      <div className="absolute inset-0 bg-grain opacity-40" />

      <div className="relative mx-auto w-[min(1240px,94%)]">
        <SectionHeading
          eyebrow="Sacred Destinations"
          title={
            <>
              Seven Shrines. <span className="gold-gradient-text">One Divine Path.</span>
            </>
          }
          subtitle="Handpicked pilgrim circuits across South India's most revered temples — each journey guided with devotion and care."
        />

        <div className="mt-16 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {destinations.map((d, i) => (
            <motion.article
              key={d.slug}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: (i % 3) * 0.08 }}
              className={`group relative flex flex-col overflow-hidden rounded-3xl border border-gold-soft bg-ink-card transition duration-500 hover:-translate-y-1.5 hover:border-gold/60 hover:shadow-[0_30px_80px_-30px_rgba(214,169,79,0.4)] ${
                d.highlight ? "lg:col-span-1" : ""
              }`}
            >
              {/* Image */}
              <div className="relative aspect-[4/5] overflow-hidden">
                <img
                  src={d.image}
                  alt={d.name}
                  className="h-full w-full object-cover transition duration-700 group-hover:scale-110"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/30 to-transparent" />
                {d.highlight && (
                  <span className="absolute left-4 top-4 inline-flex items-center gap-1.5 rounded-full bg-gold px-3 py-1 text-xs font-bold text-[#1a1208]">
                    <Sparkles className="h-3 w-3" />
                    Popular
                  </span>
                )}
                {/* Deity badge */}
                <span className="absolute bottom-4 left-4 rounded-full border border-gold-soft bg-ink/80 px-3 py-1 text-xs font-medium text-gold-soft backdrop-blur-sm">
                  {d.deity}
                </span>
              </div>

              {/* Body */}
              <div className="flex flex-1 flex-col p-6">
                <div className="mb-2 flex items-start justify-between gap-3">
                  <div>
                    <h3 className="font-serif text-2xl font-bold text-cream">
                      {d.name}
                    </h3>
                    <p className="font-display text-sm italic text-gold-soft">
                      {d.tagline}
                    </p>
                  </div>
                  <ArrowUpRight className="h-5 w-5 shrink-0 text-gold/60 transition group-hover:rotate-12 group-hover:text-gold" />
                </div>
                <p className="mt-2 flex-1 text-sm leading-relaxed text-cream/70">
                  {d.description}
                </p>
                <div className="mt-4 flex items-center gap-1.5 text-xs font-medium text-cream-dim">
                  <MapPin className="h-3.5 w-3.5 text-gold" />
                  {d.location}
                </div>
              </div>
              {/* gold edge on hover */}
              <span className="pointer-events-none absolute inset-x-0 bottom-0 h-px scale-x-0 bg-gradient-to-r from-transparent via-gold to-transparent transition-transform duration-500 group-hover:scale-x-100" />
            </motion.article>
          ))}

          {/* CTA card */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.5, delay: 0.16 }}
            className="relative flex flex-col justify-center overflow-hidden rounded-3xl border border-gold/40 bg-gradient-to-br from-[#241a0c] via-ink-card to-ink p-8"
          >
            <div className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-gold/15 blur-3xl" />
            <h3 className="font-serif text-3xl font-bold text-cream">
              Custom <span className="gold-gradient-text">Pilgrimage</span>
            </h3>
            <p className="mt-3 text-sm text-cream/70">
              Combine any of these divine destinations into a single soulful
              journey. Tell us your dates, group size, and darshan preferences —
              we craft the rest.
            </p>
            <a
              href="#inquiry"
              className="mt-6 inline-flex w-fit items-center gap-2 rounded-full bg-gold px-6 py-3 text-sm font-bold text-[#1a1208] transition hover:bg-gold-bright"
            >
              Plan My Journey
              <ArrowUpRight className="h-4 w-4" />
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
