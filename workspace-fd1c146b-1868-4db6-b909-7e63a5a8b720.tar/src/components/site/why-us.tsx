"use client";

import { motion } from "framer-motion";
import { whyCards, stats } from "@/lib/data";
import { SectionHeading } from "./section-heading";

export function WhyUs() {
  return (
    <section id="why" className="relative overflow-hidden bg-ink py-24 sm:py-32">
      <div className="absolute inset-0 bg-grain opacity-30" />
      <div className="relative mx-auto w-[min(1240px,94%)]">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-[1.1fr_1fr] lg:items-center">
          {/* Left: heading + why cards */}
          <div>
            <SectionHeading
              align="left"
              eyebrow="Why Baadshah"
              title={
                <>
                  Miles of <span className="gold-gradient-text">Trust.</span>
                  <br />
                  Memories for Life.
                </>
              }
              subtitle="For over a decade, devotees have trusted us to carry their faith across South India's sacred geography — with safety, dignity, and devotion."
            />

            <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2">
              {whyCards.map((w, i) => {
                const Icon = w.icon;
                return (
                  <motion.div
                    key={w.title}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: "-60px" }}
                    transition={{ duration: 0.45, delay: (i % 2) * 0.08 }}
                    className="rounded-2xl border border-gold-soft bg-ink-card/60 p-5 transition hover:border-gold/50"
                  >
                    <div className="mb-3 grid h-11 w-11 place-items-center rounded-xl border border-gold/40 bg-gradient-to-br from-[#2a1f0e] to-ink text-gold">
                      <Icon className="h-5 w-5" />
                    </div>
                    <h3 className="font-serif text-lg font-bold text-cream">
                      {w.title}
                    </h3>
                    <p className="mt-1.5 text-sm leading-relaxed text-cream/70">
                      {w.text}
                    </p>
                  </motion.div>
                );
              })}
            </div>
          </div>

          {/* Right: image + stats overlay */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="relative overflow-hidden rounded-[2rem] border border-gold-soft">
              <img
                src="/cta-journey.jpg"
                alt="Spiritual travel essentials"
                className="aspect-[4/5] w-full object-cover sm:aspect-[5/6]"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/40 to-transparent" />
              {/* floating contact card */}
              <div className="absolute inset-x-5 bottom-5 rounded-2xl border border-gold/50 bg-ink/85 p-5 backdrop-blur-md">
                <p className="font-display text-xs tracking-[0.3em] text-gold uppercase">
                  Speak to your travel desk
                </p>
                <p className="mt-1 font-serif text-2xl font-bold text-cream">
                  Proprietor · Babji (Baadshah)
                </p>
                <a
                  href="tel:+918328269906"
                  className="mt-1 inline-block font-serif text-3xl font-black gold-gradient-text"
                >
                  8328269906
                </a>
                <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1 text-xs text-cream/70">
                  <span>Chennai</span>
                  <span className="text-gold">·</span>
                  <span>Bangalore</span>
                  <span className="text-gold">·</span>
                  <span>24/7 Support</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Stats bar */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.6 }}
          className="mt-16 grid grid-cols-2 gap-px overflow-hidden rounded-3xl border border-gold-soft bg-gold-soft sm:grid-cols-4"
        >
          {stats.map((s) => (
            <div key={s.label} className="bg-ink-card p-7 text-center">
              <div className="font-serif text-4xl font-black gold-gradient-text sm:text-5xl">
                {s.value}
              </div>
              <div className="mt-1.5 font-display text-xs tracking-[0.25em] text-cream/70 uppercase">
                {s.label}
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
