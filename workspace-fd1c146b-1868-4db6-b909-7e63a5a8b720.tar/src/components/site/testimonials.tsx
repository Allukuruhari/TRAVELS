"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Star, Quote, ChevronLeft, ChevronRight } from "lucide-react";
import { testimonials } from "@/lib/data";
import { SectionHeading } from "./section-heading";

export function Testimonials() {
  const [idx, setIdx] = useState(0);
  const t = testimonials[idx];
  const next = () => setIdx((i) => (i + 1) % testimonials.length);
  const prev = () => setIdx((i) => (i - 1 + testimonials.length) % testimonials.length);

  return (
    <section
      id="testimonials"
      className="relative overflow-hidden bg-ink-soft py-24 sm:py-32"
    >
      <div className="pointer-events-none absolute left-1/2 top-0 h-[300px] w-[500px] -translate-x-1/2 rounded-full bg-gold/5 blur-[120px]" />
      <div className="absolute inset-0 bg-grain opacity-30" />

      <div className="relative mx-auto w-[min(1240px,94%)]">
        <SectionHeading
          eyebrow="Devotee Voices"
          title={
            <>
              Blessings Shared, <span className="gold-gradient-text">Trust Earned</span>
            </>
          }
          subtitle="Real journeys, real devotees, real gratitude. Here's what the Baadshah family says."
        />

        <div className="mx-auto mt-14 max-w-4xl">
          <div className="relative overflow-hidden rounded-[2rem] border border-gold-soft bg-ink-card/70 p-8 backdrop-blur-md sm:p-12">
            <Quote className="absolute right-8 top-8 h-20 w-20 text-gold/10" />
            <AnimatePresence mode="wait">
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.4 }}
                className="relative"
              >
                <div className="mb-5 flex gap-1">
                  {[...Array(t.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-gold text-gold" />
                  ))}
                </div>
                <p className="font-display text-xl leading-relaxed text-cream/90 sm:text-2xl">
                  &ldquo;{t.text}&rdquo;
                </p>
                <div className="mt-7 flex items-center gap-4">
                  <div className="grid h-12 w-12 place-items-center rounded-full bg-gradient-to-br from-[#d6a94f] to-[#b8842c] font-serif text-lg font-bold text-[#1a1208]">
                    {t.name.charAt(0)}
                  </div>
                  <div>
                    <div className="font-serif text-lg font-bold text-cream">
                      {t.name}
                    </div>
                    <div className="text-sm text-gold-soft">{t.place}</div>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          <div className="mt-6 flex items-center justify-between">
            <div className="flex gap-2">
              {testimonials.map((_, i) => (
                <button
                  key={i}
                  aria-label={`Go to testimonial ${i + 1}`}
                  onClick={() => setIdx(i)}
                  className={`h-2 rounded-full transition-all ${
                    i === idx ? "w-8 bg-gold" : "w-2 bg-gold/30 hover:bg-gold/60"
                  }`}
                />
              ))}
            </div>
            <div className="flex gap-2">
              <button
                onClick={prev}
                aria-label="Previous testimonial"
                className="grid h-11 w-11 place-items-center rounded-full border border-gold-soft text-gold transition hover:bg-gold/10"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
              <button
                onClick={next}
                aria-label="Next testimonial"
                className="grid h-11 w-11 place-items-center rounded-full border border-gold-soft text-gold transition hover:bg-gold/10"
              >
                <ChevronRight className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
